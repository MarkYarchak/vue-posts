<template>
  <div>
    <ul>
        <post-item
          v-for="(item, key) in posts"
          :key="key"
          :post="item"
        />
    </ul>
  </div>
</template>

<script>
import PostItem from './PostItem';
export default {
components: {
PostItem,
        },
    data() {
     return {
     posts: [
          {
            author: {
                  displayName: 'Derek Russel',
                  username: '@derek.russell',
                  avatar: 'http://posta-magazine.ru/images/stories/flexicontent2/1_DerekBlasberg-youtube_posta-magazine.jpg',
                    },
            createDate: '16m',
            content: {
                text: '',
                imageUrl: 'https://wallpaperbrowse.com/media/images/70258224-full-hd-wallpapers.jpeg',
                },
            comments: [
              {
                author: {
                  displayName: '',
                  username: '',
                  avatar: 'https://wallpaper.wiki/wp-content/uploads/2017/05/Free-HD-Corvette-Wallpapers-Images.jpg',
                },
                comment: '',
                createDate: '',
              },
              {
                author: {
                  displayName: '',
                  username: '',
                  avatar: 'https://jooinn.com/images/girl-162.jpg',
                },
                comment: '',
                createDate: '',
              },
              {
                author: {
                  displayName: '',
                  username: '',
                  avatar: 'http://diarioveaonline.com/wp-content/uploads/2018/06/excellent-wallpaper-full-hd-for-desktop-27.jpg',
                },
                comment: '',
                createDate: '',
              },
              {
                author: {
                  displayName: '',
                  username: '',
                  avatar: '',
                },
                comment: '',
                createDate: '',
              },
              ],
              likes: [
                {
                  displayName: '',
                  username: '',
                  avatar: 'https://jooinn.com/images/girl-162.jpg',
                },
              ],
          },
          {
            author: {
                displayName: 'Joe Mitchell',
                username: '@jmitch',
                avatar: 'https://pbs.twimg.com/profile_images/943567052790534144/wOEOj_EB_400x400.jpg',
                    },
            createDate: '42m',
            content: {
                text: 'Anyone need a spare ticket for the Worry Dolls show at the Borderline?',
                imageUrl: '',
                },
            comments: [
              {
                author: {
                  displayName: '',
                  username: '',
                  avatar: 'http://aspekty.net/wp-content/uploads/2017/05/vzglyad.jpeg',
                },
                comment: '',
                createDate: '',
              },
              {
                author: {
                  displayName: '',
                  username: '',
                  avatar: 'https://wallpaperbrowse.com/media/images/4224848-boy-pic.jpg',
                },
                comment: '',
                createDate: '',
              },
              {
                author: {
                  displayName: '',
                  username: '',
                  avatar: 'http://www.kinyu-z.net/data/wallpapers/56/897774.jpg',
                },
                comment: '',
                createDate: '',
              },
              {
                author: {
                  displayName: '',
                  username: '',
                  avatar: '',
                },
                comment: '',
                createDate: '',
              },
              {
                author: {
                  displayName: '',
                  username: '',
                  avatar: '',
                },
                comment: '',
                createDate: '',
              },
              {
                author: {
                  displayName: '',
                  username: '',
                  avatar: '',
                },
                comment: '',
                createDate: '',
              },
              {
                author: {
                  displayName: '',
                  username: '',
                  avatar: '',
                },
                comment: '',
                createDate: '',
              },
              {
                author: {
                  displayName: '',
                  username: '',
                  avatar: '',
                },
                comment: '',
                createDate: '',
              },
            ],
            likes: [],
          },
          {
            author: {
                displayName: 'Monica Dixon',
                username: '@monicaaa',
                avatar: 'http://statementscene.com/wp-content/uploads/2014/01/IMG_8108-750x535.jpg',
                },
            createDate: '2h',
            content: '',
            comments: [
              {
                author: {
                  displayName: '',
                  username: '',
                  avatar: 'https://www.stylecracker.com/blog/wp-content/uploads/2016/09/Slider-9-1.jpg',
                },
                comment: '',
                createDate: '',
              },
              {
                author: {
                  displayName: '',
                  username: '',
                  avatar: 'https://www.trickscity.com/wp-content/uploads/2016/12/a59b8c0c50f181e5bde6a76eff60abea.jpg',
                },
                comment: '',
                createDate: '',
              },
              {
                author: {
                  displayName: '',
                  username: '',
                  avatar: 'https://www.independent.ie/incoming/article35010156.ece/ALTERNATES/h342/iw%20IMG_9611_2.jpg',
                },
                comment: '',
                createDate: '',
              },
            ],
            likes: [],
          },
       ],
  };
},
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
